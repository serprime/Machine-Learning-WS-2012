javac -d bin -sourcepath src -cp lib/weka.jar:lib/uncommons-maths-1.2.3.jar src/at/ac/tuwien/knn/gui/MainWindow.java
