java -cp bin:lib/uncommons-maths-1.2.3.jar:lib/weka.jar at.ac.tuwien.knn.gui.MainWindow
